from .supercell import BrawlStars
from .supercell import ClashRoyale
from .supercell import ClashOfClans

__version__ = '1.1.0'
__author__ = "RoLLy"
__license__ = "MIT License"